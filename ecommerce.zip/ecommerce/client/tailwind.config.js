module.exports = {
  content: [
    "./src/**/*.{html,js,ts,jsx,tsx}", // Update with your file paths
    "./public/index.html",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
